package com.ashokit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ashokit.persistent.ContactEntity;
import com.ashokit.persistent.IContactRepo;

@Service
public class ContactServiceImpl implements IContactService{
	
	@Autowired
	private IContactRepo repo; //HAS-A

	public Integer saveContact(ContactEntity  contactEntity)
	{
		//saveContact method implemented
	}
	public List<ContactEntity> getAllContacts()
	{
		//getAllContact method implemented
	}

	public void deleteContact(Integer id)
	{
		//deleteContact method implemented
	}

	public void updateContact(ContactEntity contactEntity)
	{
		//updateContact method implemented
	}


}
