package com.ashokit.service;

import java.util.List;

import com.ashokit.model.Contact;

public interface IContactService {
	
	public Boolean saveContact(Contact c);
	public List<Contact> getAllContacts();
	public Contact getContactById(Integer cid);
	public Boolean updateContact(Contact c);
	public Boolean deleteContact(Integer cid);


}
