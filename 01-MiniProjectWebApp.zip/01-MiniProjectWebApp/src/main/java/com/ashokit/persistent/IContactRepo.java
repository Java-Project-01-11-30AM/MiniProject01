package com.ashokit.persistent;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IContactRepo extends JpaRepository<ContactEntity, Integer> {

}
