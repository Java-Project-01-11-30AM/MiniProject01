package com.ashokit.controller;

import org.springframework.beans.factory.annotation.Autowired;

import com.ashokit.service.IContactService;

public class ContactController {
	
	@Autowired
	private IContactService service; //HAS-A
	public String contactReg(){
		return null;}
	public String saveContact(){
		return null;}
	public String AllContactInfo(){
		return null;}
	public String deleteContact(){
		return null;}
	public String contactInfoEdit(){
		return null;}
	public String updateContact(){
		return null;}


}
