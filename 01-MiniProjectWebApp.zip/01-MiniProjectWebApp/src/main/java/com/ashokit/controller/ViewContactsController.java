package com.ashokit.controller;

public class ViewContactsController {
	
	public String editContact(Integer contactId);
	public String updateContact(Contact c, Model model);
	public String deleteContact(Integer contactId);


}
